package com.touchx.sensitivity;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TouchMathTest {
    @Test public void noMultiplier() { assertEquals(130f, TouchMath.scaled(100f,130f,1f,500f),0.001f); }
    @Test public void doubleSwipe() { assertEquals(160f, TouchMath.scaled(100f,130f,2f,500f),0.001f); }
    @Test public void swipeNegativeDirection() { assertEquals(40f, TouchMath.scaled(100f,80f,3f,500f),0.001f); }
    @Test public void clampAtScreenEdge() { assertEquals(300f, TouchMath.scaled(250f,300f,5f,300f),0.001f); }
    @Test public void clampAtZero() { assertEquals(0f, TouchMath.scaled(50f,-5f,2f,500f),0.001f); }
}
