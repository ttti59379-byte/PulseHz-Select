package com.touchx.sensitivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.MotionEvent;
import rikka.shizuku.Shizuku;

/** Creates exactly one non-daemon Shizuku UserService per app process. */
final class ShizukuBridge {
    private static volatile IInjector injector;
    private static volatile boolean initialized;
    private static Context context;
    private static boolean binding;
    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            injector = IInjector.Stub.asInterface(service);
            TouchAccessibilityService.refreshRunningService();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            injector = null;
            binding = false;
            TouchAccessibilityService.refreshRunningService();
        }
    };
    static synchronized void initialize(Context ctx) {
        if (initialized) return;
        context = ctx.getApplicationContext();
        initialized = true;
        Shizuku.addBinderReceivedListenerSticky(ShizukuBridge::bindIfPermitted);
        Shizuku.addBinderDeadListener(() -> {
            injector = null;
            binding = false;
            TouchAccessibilityService.refreshRunningService();
        });
        Shizuku.addRequestPermissionResultListener((requestCode, result) -> {
            if (result == PackageManager.PERMISSION_GRANTED) bindIfPermitted();
        });
    }
    static boolean isShizukuRunning() {
        try { return Shizuku.pingBinder(); } catch (Throwable ignored) { return false; }
    }
    static boolean hasPermission() {
        try { return isShizukuRunning() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) { return false; }
    }
    static void requestPermission() {
        if (!isShizukuRunning()) return;
        try { Shizuku.requestPermission(42); } catch (Throwable ignored) { }
    }
    static synchronized void bindIfPermitted() {
        if (context == null || !hasPermission() || binding) return;
        binding = true;
        try {
            Shizuku.bindUserService(new Shizuku.UserServiceArgs(
                    new ComponentName(context.getPackageName(), InjectorService.class.getName()))
                    .daemon(false).version(1).processNameSuffix("touchx_shell"), CONNECTION);
        } catch (Throwable exception) { binding = false; injector = null; }
    }
    static boolean ready() {
        IInjector candidate = injector;
        if (!hasPermission() || candidate == null) return false;
        try { return candidate.available(); } catch (RemoteException ex) { return false; }
    }
    static boolean inject(MotionEvent event, int targetUid) {
        IInjector candidate = injector;
        if (candidate == null) return false;
        try { return candidate.inject(event, targetUid); }
        catch (Throwable ex) { return false; }
    }
    /** Detailed result of the last shell-side injection attempt (not mere method existence). */
    static String lastInjectionError() {
        IInjector candidate = injector;
        if (candidate == null) return "Shell-служба Shizuku отключена";
        try { return candidate.lastError(); }
        catch (Throwable ex) { return "Ошибка диагностики Shizuku: " + ex.getClass().getSimpleName(); }
    }
    static String diagnose() {
        if (!isShizukuRunning()) return "Shizuku не запущен";
        if (!hasPermission()) return "Не выдано разрешение Shizuku";
        if (injector == null) return "Подключение shell-службы…";
        try { return injector.available() ? "Готово (инъекция доступна)" : injector.lastError(); }
        catch (Throwable ex) { return "Ошибка связи: " + ex; }
    }
}
