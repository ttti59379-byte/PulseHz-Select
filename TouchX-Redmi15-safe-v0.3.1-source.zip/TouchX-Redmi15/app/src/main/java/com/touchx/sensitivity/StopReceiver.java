package com.touchx.sensitivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public final class StopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        new Profiles(context).setEnabled(false);
        TouchAccessibilityService.stopNow();
    }
}
