package com.touchx.sensitivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MainActivity extends Activity {
    private Profiles profiles;
    private LinearLayout list;
    private TextView status;
    private CheckBox master;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        profiles = new Profiles(this);
        ShizukuBridge.initialize(this);
        ShizukuBridge.bindIfPermitted();
        buildUi();
    }
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(Color.WHITE);
        v.setPadding(dp(2), dp(6), dp(2), dp(6));
        return v;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(s);
        return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(15, 19, 29));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(22), dp(18), dp(22));
        scroll.addView(content);
        TextView header = text("TouchX • Redmi 15", 27);
        header.setTextColor(Color.rgb(116, 203, 255));
        content.addView(header);
        content.addView(text("Для Redmi 15 • HyperOS 3 • Android 16. " +
                "Работа усиления X/Y зависит от разрешений и поведения прошивки. " +
                "Сначала проведи обязательный безопасный тест. Если Android не передаёт касания, перехват автоматически выключится.", 14));
        content.addView(text("Обнаружено: " + Build.MANUFACTURER + " " + Build.MODEL +
                " • Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")", 13));
        status = text("Проверка подключения…", 14);
        content.addView(status);
        Button permission = button("1. Разрешить Shizuku");
        permission.setOnClickListener(v -> { ShizukuBridge.requestPermission(); ShizukuBridge.bindIfPermitted(); refreshStatus(); });
        content.addView(permission);
        Button accessibility = button("2. Включить службу специальных возможностей");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        content.addView(accessibility);
        Button touchTest = button("3. ТЕСТ передачи касаний — 5 секунд");
        touchTest.setOnClickListener(v -> {
            if (!TouchAccessibilityService.startSelfTest()) {
                new AlertDialog.Builder(this).setTitle("Тест не запущен")
                        .setMessage("Убедись, что Shizuku подключён, служба специальных возможностей включена и TouchX открыт на экране. Затем попробуй снова.")
                        .setPositiveButton("OK", null).show();
            }
            refreshStatus();
        });
        content.addView(touchTest);
        content.addView(text("Во время теста быстро коснись любой пустой области этого экрана. Если касания не доходят, перехват отключится автоматически. Не проверяй впервые в игре.", 13));
        master = new CheckBox(this);
        master.setText("4. Активировать игровые профили (после теста)");
        master.setTextColor(Color.WHITE);
        master.setChecked(profiles.isEnabled());
        master.setOnCheckedChangeListener((b,checked) -> {
            if (checked && (!ShizukuBridge.ready() || !TouchAccessibilityService.testPassed())) {
                b.setChecked(false);
                new AlertDialog.Builder(this).setMessage("Нужны Shizuku и успешно пройденный тест передачи касаний на этом экране. Без этого TouchX не будет перехватывать игровые касания.")
                        .setPositiveButton("OK", null).show();
                return;
            }
            profiles.setEnabled(checked);
            TouchAccessibilityService.refreshRunningService();
        });
        content.addView(master);
        Button emergency = button("АВАРИЙНЫЙ СТОП");
        emergency.setOnClickListener(v -> {
            profiles.setEnabled(false); master.setChecked(false);
            TouchAccessibilityService.stopNow();
        });
        content.addView(emergency);
        content.addView(text("Выбранные приложения — касания всего экрана. Настройка множителей X и Y от 1.0× до 5.0×. По умолчанию: X 1.2×, Y 1.1×.", 14));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);
        setContentView(scroll);
        populateApps();
        refreshStatus();
    }
    private void populateApps() {
        list.removeAllViews();
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);
        Collections.sort(apps, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase()));
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : apps) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            String name = ri.loadLabel(pm).toString();
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL);
            CheckBox check = new CheckBox(this);
            check.setText(name); check.setTextColor(Color.WHITE); check.setTextSize(13);
            check.setChecked(profiles.selected(pkg));
            check.setLayoutParams(new LinearLayout.LayoutParams(0, dp(54), 1));
            check.setOnCheckedChangeListener((b,checked) -> {
                profiles.select(pkg, checked);
                TouchAccessibilityService.refreshRunningService();
            });
            Button config = button("X/Y");
            config.setOnClickListener(v -> settingsDialog(pkg, name));
            line.addView(check); line.addView(config);
            list.addView(line);
        }
        if (seen.isEmpty()) list.addView(text("Нет доступных приложений с ярлыками запуска.", 14));
    }
    private void settingsDialog(String pkg, String title) {
        Profiles.Config initial = profiles.config(pkg);
        LinearLayout content = new LinearLayout(this);
        content.setPadding(dp(18), dp(12), dp(18), dp(4));
        content.setOrientation(LinearLayout.VERTICAL);
        TextView xLabel = text("X: " + initial.x + "×", 18);
        xLabel.setTextColor(Color.BLACK);
        SeekBar x = new SeekBar(this);
        x.setMax(40); x.setProgress(Math.round((initial.x - 1f)*10f));
        TextView yLabel = text("Y: " + initial.y + "×", 18);
        yLabel.setTextColor(Color.BLACK);
        SeekBar y = new SeekBar(this);
        y.setMax(40); y.setProgress(Math.round((initial.y - 1f)*10f));
        x.setOnSeekBarChangeListener(listener(progress -> xLabel.setText(String.format(java.util.Locale.US,"X: %.1f×",1f + progress / 10f))));
        y.setOnSeekBarChangeListener(listener(progress -> yLabel.setText(String.format(java.util.Locale.US,"Y: %.1f×",1f + progress / 10f))));
        content.addView(xLabel); content.addView(x); content.addView(yLabel); content.addView(y);
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        Button gentle = button("Мягко 1.2/1.1");
        gentle.setOnClickListener(v -> { x.setProgress(2); y.setProgress(1); });
        Button normal = button("Обычное 1.0/1.0");
        normal.setOnClickListener(v -> { x.setProgress(0); y.setProgress(0); });
        quick.addView(gentle, new LinearLayout.LayoutParams(0, dp(50), 1));
        quick.addView(normal, new LinearLayout.LayoutParams(0, dp(50), 1));
        content.addView(quick);
        new AlertDialog.Builder(this).setTitle(title + " — множитель")
                .setView(content)
                .setPositiveButton("Сохранить", (d, w) -> profiles.setConfig(pkg, 1f + x.getProgress()/10f, 1f + y.getProgress()/10f))
                .setNegativeButton("Отмена", null).show();
    }
    private interface Progress { void change(int value); }
    private SeekBar.OnSeekBarChangeListener listener(Progress fn) {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int progress, boolean fromUser) { fn.change(progress); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        };
    }
    private void refreshStatus() {
        status.setText("Shizuku: " + ShizukuBridge.diagnose() + "\n"+
                "Служба касаний: " + (TouchAccessibilityService.running == null ? "выключена" : "работает")+
                "\nТест: " + TouchAccessibilityService.testStatus() +
                "\nАктивный профиль: " + TouchAccessibilityService.currentTarget() +
                "\nЭкстренное выключение: 3 быстрых нажатия громкости ВНИЗ. Или STOP в уведомлении.");
    }
    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        TouchAccessibilityService.onTestTouchDelivered(event);
        return super.dispatchTouchEvent(event);
    }
    private final Runnable uiRefresh = new Runnable() {
        @Override public void run() {
            if (status != null) refreshStatus();
            if (status != null) status.postDelayed(this, 650L);
        }
    };
    @Override protected void onResume() {
        super.onResume();
        if (status != null) {
            master.setChecked(profiles.isEnabled());
            refreshStatus();
            status.removeCallbacks(uiRefresh);
            status.postDelayed(uiRefresh, 650L);
        }
    }
    @Override protected void onPause() {
        if (status != null) status.removeCallbacks(uiRefresh);
        super.onPause();
    }
}
