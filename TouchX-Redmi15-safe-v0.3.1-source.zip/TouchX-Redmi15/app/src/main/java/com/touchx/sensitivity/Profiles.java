package com.touchx.sensitivity;

import android.content.Context;
import android.content.SharedPreferences;

final class Profiles {
    private static final String PREF = "touchx_profiles";
    static final class Config {
        final float x, y;
        Config(float x, float y) { this.x = x; this.y = y; }
    }
    private final SharedPreferences prefs;
    Profiles(Context ctx) { prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    boolean isEnabled() { return prefs.getBoolean("master", false); }
    void setEnabled(boolean enabled) { prefs.edit().putBoolean("master", enabled).apply(); }
    boolean selected(String pkg) { return prefs.getBoolean("app_" + pkg, false); }
    void select(String pkg, boolean yes) { prefs.edit().putBoolean("app_" + pkg, yes).apply(); }
    Config config(String pkg) {
        return new Config(prefs.getFloat("x_"+pkg, 1.2f), prefs.getFloat("y_"+pkg, 1.1f));
    }
    void setConfig(String pkg, float x, float y) {
        prefs.edit().putFloat("x_"+pkg, x).putFloat("y_"+pkg, y).apply();
    }
}
