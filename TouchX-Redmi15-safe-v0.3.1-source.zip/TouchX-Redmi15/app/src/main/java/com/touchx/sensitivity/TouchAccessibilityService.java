package com.touchx.sensitivity;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Redmi 15 Android 16 experimental touch relay.
 * Interception is fail-closed: a foreground self-test is mandatory on each service connection.
 * The mandatory test actually checks whether reinjected touch reaches our Activity.
 * On Android builds that recapture injected events, it will fail and restore native touches.
 */
public final class TouchAccessibilityService extends AccessibilityService {
    private static final String CHANNEL = "touchx_safe_state";
    private static final int NOTIFICATION_ID = 44;
    private static final long TEST_TIMEOUT_MS = 5500L;
    private static final long FIRST_EVENT_TIMEOUT_MS = 10000L;
    private static final long INJECTION_RESULT_TIMEOUT_MS = 3000L;
    private static final int MODE_NONE = 0, MODE_TEST = 1, MODE_GAME = 2;

    static volatile TouchAccessibilityService running;
    private Profiles profiles;
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread senderThread;
    private Handler sender;
    private final AtomicInteger backlog = new AtomicInteger();
    private final TouchTransform transform = new TouchTransform();
    private String foreground = "";
    private int targetUid = -1;
    private int mode = MODE_NONE;
    private volatile int epoch;
    private long captureStarted;
    private long testStart;
    private long firstSourceEventAt;
    private boolean selfTestPassed;
    private boolean testInjectionAccepted;
    private boolean testTapDelivered;
    private String lastTestResult = "Не запускался";
    private int volumeTaps;
    private long firstVolumeTap;

    static String currentTarget() {
        TouchAccessibilityService s = running;
        if (s == null) return "Служба выключена";
        if (s.mode == MODE_TEST) return "Проверка касаний (временная)";
        if (s.mode == MODE_GAME) return s.foreground;
        return "Не активен";
    }
    static String testStatus() {
        TouchAccessibilityService s = running;
        if (s == null) return "Служба не запущена";
        if (s.mode == MODE_TEST) return "Тест идёт: коснись экрана, затем подожди до 6 секунд";
        return (s.selfTestPassed ? "Тест пройден в этой сессии" : "Тест НЕ пройден")
                + " — " + s.lastTestResult;
    }
    static boolean testPassed() {
        TouchAccessibilityService s = running;
        return s != null && s.selfTestPassed && ShizukuBridge.ready();
    }
    static void refreshRunningService() {
        TouchAccessibilityService s = running;
        if (s != null) s.main.post(s::refreshCapture);
    }
    static boolean startSelfTest() {
        TouchAccessibilityService s = running;
        if (s == null || Looper.myLooper() != Looper.getMainLooper()) return false;
        return s.beginSelfTest();
    }
    /** Called only by our Activity when an actual event reaches its window. */
    static void onTestTouchDelivered(MotionEvent event) {
        TouchAccessibilityService s = running;
        if (s == null || s.mode != MODE_TEST) return;
        if (event.getActionMasked() != MotionEvent.ACTION_UP) return;
        // We create relayed MotionEvents with device id -1. Do not trust a physical tap
        // which may arrive while setMotionEventSources is still being enabled.
        if (event.getDeviceId() != -1 || SystemClock.uptimeMillis() - s.testStart < 350L) return;
        s.testTapDelivered = true;
        s.finishTestIfReady();
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        running = this;
        profiles = new Profiles(this);
        // An upgrade/reboot must NEVER silently resume touchscreen interception.
        profiles.setEnabled(false);
        senderThread = new HandlerThread("TouchX-SafeInjector");
        senderThread.start();
        sender = new Handler(senderThread.getLooper());
        ShizukuBridge.initialize(this);
        ShizukuBridge.bindIfPermitted();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                "TouchX безопасное управление", NotificationManager.IMPORTANCE_LOW));
        setCaptureSources(false);
        updateForeground();
        main.post(watchdog);
    }

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (running != TouchAccessibilityService.this) return;
            updateForeground();
            long now = SystemClock.uptimeMillis();
            if (mode == MODE_TEST && now - testStart >= TEST_TIMEOUT_MS)
                stopCapture("Тест не пройден: касания не дошли до приложения", true);
            else if (mode == MODE_GAME) {
                if (!ShizukuBridge.ready()) stopCapture("Shizuku отключён", true);
                else if (firstSourceEventAt == 0 && now - captureStarted >= FIRST_EVENT_TIMEOUT_MS)
                    stopCapture("Нет подтверждения получения касаний", true);
                else if (firstSourceEventAt > 0 &&
                        now - firstSourceEventAt >= INJECTION_RESULT_TIMEOUT_MS && backlog.get() > 0)
                    stopCapture("Отправка касаний зависла", true);
            }
            if (mode != MODE_TEST) refreshCapture();
            main.postDelayed(this, 250L);
        }
    };

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getPackageName() != null)
            updatePackage(event.getPackageName().toString());
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            updateForeground();
            if (mode != MODE_TEST) refreshCapture();
        }
    }
    private void updateForeground() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence pkg = root.getPackageName();
                if (pkg != null && pkg.length() > 0) updatePackage(pkg.toString());
                root.recycle();
            }
        } catch (Throwable ignored) { }
    }
    private void updatePackage(String pkg) {
        if (pkg.equals(foreground)) return;
        if (mode == MODE_GAME) stopCapture("Открыто другое приложение", true);
        else if (mode == MODE_TEST && !pkg.equals(getPackageName())) {
            stopCapture("Тест прерван: переключение окна", true);
        }
        foreground = pkg;
        try { targetUid = getPackageManager().getApplicationInfo(pkg, 0).uid; }
        catch (PackageManager.NameNotFoundException ex) { targetUid = -1; }
    }
    private boolean beginSelfTest() {
        if (mode != MODE_NONE || !ShizukuBridge.ready() || sender == null) return false;
        updateForeground();
        if (!getPackageName().equals(foreground)) {
            lastTestResult = "Открой главный экран TouchX для проверки";
            return false;
        }
        selfTestPassed = false;
        testInjectionAccepted = false;
        testTapDelivered = false;
        testStart = SystemClock.uptimeMillis();
        firstSourceEventAt = 0;
        captureStarted = testStart;
        mode = MODE_TEST;
        epoch++;
        transform.reset();
        if (!setCaptureSources(true)) {
            stopCapture("Система запретила перехват", true);
            return false;
        }
        updateNotification();
        return true;
    }
    private void finishTestIfReady() {
        if (mode != MODE_TEST || !testTapDelivered || !testInjectionAccepted) return;
        stopCapture("Тест пройден: касания дошли до TouchX", false);
        selfTestPassed = true;
        lastTestResult = "Успешная доставка касания в собственное окно";
    }
    private void refreshCapture() {
        if (profiles == null || mode == MODE_TEST) return;
        boolean want = profiles.isEnabled() && selfTestPassed &&
                targetUid >= 10000 && profiles.selected(foreground) && ShizukuBridge.ready();
        if (want && mode == MODE_NONE) {
            mode = MODE_GAME;
            epoch++;
            transform.reset();
            captureStarted = SystemClock.uptimeMillis();
            firstSourceEventAt = 0;
            if (!setCaptureSources(true)) stopCapture("Не удалось включить перехват", true);
            updateNotification();
        } else if (!want && mode == MODE_GAME) stopCapture("Профиль отключён", false);
    }
    private boolean setCaptureSources(boolean enabled) {
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) return false;
            info.setMotionEventSources(enabled ? InputDevice.SOURCE_TOUCHSCREEN : 0);
            setServiceInfo(info);
            return true;
        } catch (Throwable ex) { return false; }
    }

    @Override public void onMotionEvent(MotionEvent original) {
        final int capturedMode = mode;
        if (capturedMode == MODE_NONE ||
                !original.isFromSource(InputDevice.SOURCE_TOUCHSCREEN)) return;
        // Relayed events that return to this service MUST NOT be recursively reinjected.
        if (original.getDeviceId() == -1) return;
        if (!ShizukuBridge.ready()) { stopCapture("Shizuku недоступен", true); return; }
        int destUid = capturedMode == MODE_TEST ? getApplicationInfo().uid : targetUid;
        if (destUid < 10000) { stopCapture("UID приложения недоступен", true); return; }
        if (backlog.get() > 8) { stopCapture("Очередь касаний переполнена", true); return; }
        if (firstSourceEventAt == 0) firstSourceEventAt = SystemClock.uptimeMillis();
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display display = dm == null ? null : dm.getDisplay(Display.DEFAULT_DISPLAY);
        if (display == null) { stopCapture("Экран недоступен", true); return; }
        Point size = new Point();
        display.getRealSize(size);
        Profiles.Config config = capturedMode == MODE_TEST ?
                new Profiles.Config(1f, 1f) : profiles.config(foreground);
        MotionEvent out = transform.scale(original, config.x, config.y, size.x, size.y);
        int enqueuedEpoch = epoch;
        backlog.incrementAndGet();
        if (!sender.post(() -> {
            boolean delivered = false;
            try {
                // Stale input from a previous game/test must never be injected.
                if (enqueuedEpoch == epoch) delivered = ShizukuBridge.inject(out, destUid);
            } catch (Throwable ignored) { }
            finally {
                out.recycle();
                backlog.decrementAndGet();
            }
            final boolean ok = delivered;
            main.post(() -> {
                if (enqueuedEpoch != epoch) return;
                if (!ok) {
                    stopCapture("Системная отправка касания не удалась: "
                            + ShizukuBridge.lastInjectionError(), true);
                } else if (capturedMode == MODE_TEST && mode == MODE_TEST) {
                    testInjectionAccepted = true;
                    finishTestIfReady();
                }
            });
        })) {
            out.recycle();
            backlog.decrementAndGet();
            stopCapture("Очередь отправки недоступна", true);
        }
    }
    /** Restore physical touch first. This method is safe to call repeatedly. */
    private void stopCapture(String message, boolean failure) {
        int oldMode = mode;
        mode = MODE_NONE;
        epoch++;
        if (!setCaptureSources(false)) {
            // If the OS refuses to reset the source filter, disable this accessibility
            // service altogether rather than leave hardware touch captured.
            try { disableSelf(); } catch (Throwable ignored) { }
        }
        transform.reset();
        if (failure) {
            if (profiles != null) profiles.setEnabled(false);
            if (oldMode == MODE_TEST) {
                selfTestPassed = false;
                lastTestResult = message;
            }
            if (oldMode != MODE_NONE)
                Toast.makeText(this, "TouchX отключён: " + message, Toast.LENGTH_LONG).show();
        } else if (oldMode == MODE_TEST) lastTestResult = message;
        updateNotification();
    }
    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (mode == MODE_NONE) { nm.cancel(NOTIFICATION_ID); return; }
        PendingIntent stop = PendingIntent.getBroadcast(this, 1,
                new Intent(this, StopReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
                .setContentTitle(mode == MODE_TEST ? "TouchX: тест касаний (5 сек)" : "TouchX: активен " + foreground)
                .setContentText("Автоостановка при сбое. Можно нажать СТОП")
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_delete,"СТОП",stop).build())
                .setOngoing(true).build();
        try { nm.notify(NOTIFICATION_ID, n); } catch (Throwable ignored) { }
    }
    static void stopNow() {
        TouchAccessibilityService s = running;
        if (s != null) s.main.post(() -> s.stopCapture("Отключено пользователем", true));
    }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN &&
                event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            long now = SystemClock.uptimeMillis();
            if (now - firstVolumeTap > 2000L) { firstVolumeTap = now; volumeTaps = 0; }
            if (++volumeTaps >= 3) {
                volumeTaps = 0;
                stopCapture("3 нажатия громкости вниз", true);
            }
        }
        return false;
    }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        stopCapture("Служба закрыта", true);
        running = null;
        main.removeCallbacks(watchdog);
        if (senderThread != null) senderThread.quitSafely();
        super.onDestroy();
    }
}
