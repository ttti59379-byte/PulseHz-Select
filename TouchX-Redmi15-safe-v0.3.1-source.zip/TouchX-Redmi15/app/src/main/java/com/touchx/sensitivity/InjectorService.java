package com.touchx.sensitivity;

import android.os.IBinder;
import android.os.Process;
import android.view.InputEvent;
import android.view.MotionEvent;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

/** Runs as Shizuku's shell UID (2000), not as an ordinary Android Service. */
public final class InjectorService extends IInjector.Stub {
    private Object inputManager;
    private Method injectTarget;
    private String error = "Not initialized";

    public InjectorService() {
        try {
            if (Process.myUid() != 2000) {
                error = "Not running as adb shell UID 2000";
                return;
            }
            Class<?> sm = Class.forName("android.os.ServiceManager");
            IBinder binder = (IBinder) sm.getMethod("getService", String.class)
                    .invoke(null, "input");
            if (binder == null) throw new IllegalStateException("input service not found");
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            Object manager = stub.getMethod("asInterface", IBinder.class).invoke(null, binder);
            Method target = manager.getClass().getMethod("injectInputEventToTarget",
                    InputEvent.class, int.class, int.class);
            inputManager = manager;
            injectTarget = target;
            error = "OK";
        } catch (Throwable failure) { error = failure.toString(); }
    }

    @Override public boolean available() { return injectTarget != null; }
    @Override public String lastError() { return error; }

    @Override public synchronized boolean inject(MotionEvent event, int targetUid) {
        if (injectTarget == null || targetUid < 10000 || event == null) return false;
        try {
            // 1 = WAIT_FOR_RESULT. Unlike async mode, Android reports routing failures
            // such as mismatched target windows. No untargeted fallback is ever allowed.
            Object result = injectTarget.invoke(inputManager, event, 1, targetUid);
            boolean ok = Boolean.TRUE.equals(result);
            if (!ok) error = "injectInputEventToTarget returned false";
            return ok;
        } catch (Throwable failure) {
            Throwable root = failure instanceof InvocationTargetException
                    ? ((InvocationTargetException) failure).getTargetException() : failure;
            error = "Injection error: " + root.getClass().getSimpleName()
                    + (root.getMessage() == null ? "" : ": " + root.getMessage());
            return false;
        }
    }
    @Override public void destroy() { System.exit(0); }
}
