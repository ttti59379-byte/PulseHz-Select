# TouchX Redmi 15 v0.3.1 — diagnostic display fix

This revision addresses an observed **system input injection failure** on Redmi 15, Android 16, HyperOS 3.

Changes:
- The synthetic MotionEvent now explicitly preserves the physical event's `displayId` using the API 34+ `MotionEvent.obtain` overload, rather than relying on the legacy constructor's default. Android's shell `input` command also explicitly sets display ID for pointer events.
- Shizuku `InjectorService` unwraps reflection exceptions and retains a detailed error (`SecurityException`, target UID mismatch, etc.).
- The safe 5-second test displays the real shell-side rejection reason instead of a generic failure.
- Kept the fail-closed behavior: failed test **disables interception** and blocks game profiles.
- Same package ID as v0.3, versionCode 4, so an APK signed with the same key can update it.

**Important:** This is a best-effort diagnostic patch, not a proven fix. Injection can remain blocked on Android 16/HyperOS 3, and access through Shizuku alone does not establish permission to inject a valid gesture. If the test fails, do not enable game interception; retain normal touch behavior. Debug APK signing keys can differ between builds, causing an update installation conflict.

## How to use

1. Install APK, grant Shizuku, and enable TouchX accessibility service.
2. Open TouchX and select **3. ТЕСТ передачи касаний — 5 секунд**.
3. Tap **another blank area** of TouchX during the test (not the launch button).
4. Test status must show `Тест пройден`. If it says `НЕ пройден`, **do not** try
   to enable the game profile. The OS or Shizuku injection is unsupported.
5. Only after a passing test, select Free Fire and use X=1.2 / Y=1.1 initially,
   then check `4. Активировать игровые профили`.
6. If problems occur, immediately disable accessibility service in Android
   settings; three quick volume-down presses are a best-effort fallback.

**This does not guarantee delivery to Free Fire.** A successful self-test
validates TouchX's own window only, not the game window. Injection into apps
may be rejected by HyperOS or game security; use could violate game rules.

## GitHub Actions build

Upload `TouchX-Redmi15-safe-v0.3-source.zip` to the *root* of your repository;
use the separate supplied `build-apk.yml` at `.github/workflows/main.yml`.
The CI job unpacks the ZIP and executes `gradle :app:assembleDebug` with Java 17,
Gradle 8.9 and Android SDK 35. APK is available under the run's Artifacts.

No Android SDK or Gradle was available locally when preparing this source
archive; compilation was **not** verified locally. This is a best-effort fix.
