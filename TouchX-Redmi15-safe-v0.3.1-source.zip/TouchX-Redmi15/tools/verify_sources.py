#!/usr/bin/env python3
"""Offline checks only. Does not replace an Android SDK/Gradle build."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re

root = Path(__file__).resolve().parents[1]
files = [
    'settings.gradle', 'build.gradle', 'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/aidl/com/touchx/sensitivity/IInjector.aidl',
    'app/src/main/java/com/touchx/sensitivity/MainActivity.java',
    'app/src/main/java/com/touchx/sensitivity/ShizukuBridge.java',
    'app/src/main/java/com/touchx/sensitivity/TouchAccessibilityService.java',
    'app/src/main/java/com/touchx/sensitivity/InjectorService.java',
    '.github/workflows/build-apk.yml',
]
for name in files:
    assert (root/name).is_file(), name
for path in (root/'app/src/main').rglob('*.xml'):
    ET.parse(path)
manifest = (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERACT_ACROSS_USERS_FULL' in manifest
assert 'rikka.shizuku.ShizukuProvider' in manifest
aidl = (root/'app/src/main/aidl/com/touchx/sensitivity/IInjector.aidl').read_text()
assert re.search(r'void\s+destroy\(\)\s*=\s*16777114\s*;', aidl)
assert all(re.search(r'=\s*'+str(i)+r'\s*;',aidl) for i in [1,2,3])
print('OK: structure, XML, Shizuku manifest, AIDL transaction IDs')
print('Not checked: Gradle/Android compilation and runtime touch injection')
